#  [![Aimed at](https://img.shields.io/badge/For%20Rimworld-1.0-orange.svg?style=plastic)]()   [![GitHub release version](https://img.shields.io/github/release/kaptain-kavern/CK_AnimalPlant_Pack.svg?style=plastic&label=Version)](https://github.com/kaptain-kavern/CK_AnimalPlant_Pack/releases/latest)   [![Github Downloads](https://img.shields.io/github/downloads/kaptain-kavern/CK_AnimalPlant_Pack/total.svg?label=Github%20Downloads&logo=github&logoColor=green&style=plastic)](https://github.com/kaptain-kavern/CK_AnimalPlant_Pack/releases/latest)   [![Steam Subscribers](https://img.shields.io/steam/subscriptions/1110093272.svg?color=blue&label=Steam%20Subscribers&logo=steam&logoColor=9cf&style=plastic)](https://steamcommunity.com/sharedfiles/filedetails/?id=1110093272)

# Tropi[CKAPP] Rainforest Mod
The purpose of this mod is to add a significant amount of new animals and plants to the game and increase fauna and flora biome diversity.

### Updated to 1.0 by with the help of Github user : [mattragoza](https://github.com/mattragoza)

## Support on Beerpay
Liked the mod! Help me out for a couple of :beers:!

[![Beerpay](https://beerpay.io/kaptain-kavern/CK_AnimalPlant_Pack/badge.svg?style=beer-square)](https://beerpay.io/kaptain-kavern/CK_AnimalPlant_Pack)  [![Beerpay](https://beerpay.io/kaptain-kavern/CK_AnimalPlant_Pack/make-wish.svg?style=flat-square)](https://beerpay.io/kaptain-kavern/CK_AnimalPlant_Pack?focus=wish)
